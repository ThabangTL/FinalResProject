$(document).ready(function(){

$( 'menu').click(function)({
    $(this).toggleClass('fa-times');
    $('header').toggleClass('toggle);
});
        
$(window).document('scroll load',function(){

  $(this).remove('fa-times');
  $('header').remove('toggle)  

  if($(window).scrollTop() > 0){
    $('.top').show();
  }else{
    $('.top').hide();

});

//smooth scrolling

 $('a[href*="#"]').click(function(e){

    e.preventDefault();

    $('html, body').animate({

        scrollTop : $($(this).attr('hre')).offest().scrollTop,

    },
      500
      'linear'
    );
 })

});